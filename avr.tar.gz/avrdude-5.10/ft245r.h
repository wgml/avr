#ifndef ft245r_h
#define ft245r_h

#include "avrpart.h"

void ft245r_initpgm (PROGRAMMER * pgm);

#endif /* ft245r_h */
